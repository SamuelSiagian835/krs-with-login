

<?php


session_start();

// Database configuration
$host = 'localhost';
$username = 'root';
$password = 'samuel123';
$database = 'card';

// Create a new PDO instance
$dsn = "mysql:host=$host;dbname=$database";
$pdo = new PDO($dsn, $username, $password);

// Process selected courses
// Process selected courses
if (isset($_POST['selectedCourses']) && isset($_POST['nim'])) {
    $selectedCourses = $_POST['selectedCourses'];
    $nim = $_POST['nim'];

    // Check if the selected courses already exist for the given nim
    $existingCoursesQuery = "SELECT course_id FROM student_course WHERE student_id = :nim";
    $existingCoursesStmt = $pdo->prepare($existingCoursesQuery);
    $existingCoursesStmt->bindParam(':nim', $nim);
    $existingCoursesStmt->execute();
    $existingCourses = $existingCoursesStmt->fetchAll(PDO::FETCH_COLUMN);

    $duplicateCourses = array_intersect($selectedCourses, $existingCourses);

    if (!empty($duplicateCourses)) {
        echo "<p>Selected courses already exist for NIM: $nim</p>";
    } else {
        // Convert the selectedCourses array to a comma-separated string
        $selectedCoursesString = implode(',', $selectedCourses);

        // Prepare and execute SQL query to insert the selected courses
        $query = "INSERT INTO student_course (student_id, course_id) VALUES ";
        $values = [];

        foreach ($selectedCourses as $courseId) {
            $values[] = "('$nim', '$courseId')";
        }

        $query .= implode(',', $values);
        $stmt = $pdo->prepare($query);
        $stmt->execute();

        // Redirect to view.php with the NIM parameter
        header("Location: view.php?nim=$nim");
        exit();
    }
}


// Display course data in a table
echo "<h2>Course List:</h2>";
echo "<form method='post' action='course.php'>"; // Form to submit the selected courses
echo "<table>";
echo "<tr><th>ID</th><th>Course Name</th><th>Credit Hours</th><th>Select</th></tr>";

// Fetch all courses from the database
$query = "SELECT * FROM course";
$stmt = $pdo->query($query);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $id = $row['id'];
    $courseName = $row['course_name'];
    $creditHours = $row['credit_hours'];

    echo "<tr>";
    echo "<td>$id</td>";
    echo "<td>$courseName</td>";
    echo "<td>$creditHours</td>";
    echo "<td><input type='checkbox' name='selectedCourses[]' value='$id'></td>"; // Checkbox for course selection
    echo "</tr>";
}

echo "</table>";
echo "<label for='nim'>NIM:</label>";
echo "<input type='text' name='nim' id='nim' required>";
echo "<input type='submit' value='Submit'>";
echo "</form>";

echo "<a href='students.php'>&larr; Back to Students</a>";
// Close the database connection
$pdo = null;
?>
